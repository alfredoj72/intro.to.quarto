#- render parametrised reports
fs::dir_create("informes")

#- elegimos países -----
paises <- c("ESP", "SVN")

nn_paises <- length(paises)


for (ii in 1:nn_paises){
  my_pais = paises[ii]
  my_informe <- paste0("informe-", my_pais, ".html")
  quarto::quarto_render(
    input = "02_informe_parametrizado_infla.qmd",
    output_file = my_informe,
    execute_params = list(country = my_pais)
  )
  full_path_source <- here::here(my_informe)
  full_path_destination <- here::here("informes", my_informe)
  fs::file_move(full_path_source, full_path_destination)
}
