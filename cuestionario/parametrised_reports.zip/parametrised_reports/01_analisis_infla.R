
#- plot temporales inflación OCDE ----------------------------------------------
library(tidyverse)
library(gt)


#- Datos -----------------------------------------------------------------------
#- Inflación de la OCDE -
ruta_inflation <- "./datos/DP_LIVE_22032023113248591.csv"

inflation_orig <- readr::read_csv(ruta_inflation)
inflation_dicc <- pjpv.curso.R.2022::pjp_dicc(inflation_orig)
inflation_uniques <- pjpv.curso.R.2022::pjp_valores_unicos(inflation_orig)

#- data munging --
inflation <- inflation_orig %>%
  dplyr::filter(FREQUENCY == "M") %>%
  dplyr::filter(MEASURE == "AGRWTH") %>%
  dplyr::mutate(fecha = lubridate::ym(TIME)) %>%
  select(pais = LOCATION, fecha, inflacion = Value, tipo_inf = SUBJECT)

#- incorporar region para filtrar grupos de países (!!!!)
zz <- countrycode::codelist %>%
  select(iso.name.en, region, region23, wb, fips, ioc, imf, iso2c, iso3c, ecb, eurostat, continent, eu28, un, un.region.name)
#zz <- countrycode::codelist %>% select(iso.name.en, region23, region, iso3c)

inflation <- left_join(inflation, zz, by = join_by(pais == iso3c) ) # %>% distinct(pais, .keep_all = TRUE)



#- PLOTS -----------------------------------------------------------------------
library(ggtext) # package to interpret HTML with element_markdown to color titles
library(showtext) # for specific fonts; font_add_google
library(glue)

# Fuentes y opciones
font_add_google("Fira Sans Condensed")
showtext_opts(dpi = 300)
showtext_auto(enable = TRUE)


#- AQUI elegimos país ------------------------
my_pais <- "ESP"


# Fuentes
font_add_google("Roboto")
showtext_auto()

#- solo Europa (q no sea Europa del Este) desde 2020
my_fecha <-  "2020-01-01"

df <- inflation %>%
  dplyr::filter(un.region.name %in% c("Europe")) %>%
  dplyr::filter(!(region23 %in% c("Eastern Europe")))  %>%
  dplyr::filter(fecha >= my_fecha)

my_title <- "Tasas de inflación interanual en Europa (enero 2020, marzo 2023)"
my_subtitle <- paste0("Países europeos y <span style='color:#FED459'>", my_pais, "</span> ")


p3 <-
  ggplot(df, aes(x = fecha, y = inflacion)) +
  geom_line(aes(group = pais), color = "white", linewidth = 0.3, alpha = 0.3) +
  geom_line(data = df %>% filter(pais == my_pais), aes(color = pais, group = pais), color = "#FED459", linewidth = 1) +
  geom_point(data = df %>% filter(pais == my_pais), aes(color = pais, group = pais), color = "#FED459", size = 1.2) +
  theme(legend.position = "none") +
  facet_wrap(vars(tipo_inf), nrow = 2, ncol = 2, scales = "free") +
  #scale_x_discrete(breaks = seq(2020:01,2023:03, by=2)) +
  labs(title = my_title, subtitle = my_subtitle,
       caption = "Datos de la OCDE |   DataViz: Pedro J. Pérez") +
  theme(plot.background = element_rect(fill = "#171717", color = "#171717"),
        panel.background = element_rect(fill = "#171717"),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        plot.title = element_markdown(family = "Roboto",color = "white", size = 11, margin = margin(20,0,0,0)),
        plot.subtitle = element_markdown(family = "Roboto", color = "white", size = 10, margin = margin(5,0,10,0)),
        plot.caption = element_text(family = "Roboto", hjust = 0.95, color = "grey70", size = 7, margin = margin(0,0,20,0)),
        axis.title.x = element_blank(),
        axis.text.x = element_text(color = "grey70", size = 6.4, margin = margin(0,20,20,0), angle = 90),
        axis.text.y = element_text(color = "grey70", size = 6.7),
        axis.title.y = element_blank(),
        strip.background = element_rect(fill = "#171717"),
        strip.text.x = element_text(color = "white"))

p3


plotly::ggplotly(p3)
