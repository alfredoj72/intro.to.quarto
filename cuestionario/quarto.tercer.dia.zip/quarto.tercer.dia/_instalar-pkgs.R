#- instalación de paquetes ---------------------------------

install.packages("pak")

pak::pak(c("tidyverse", "ggtext",  "curl", "perezp44/pjpv.curso.R.2022", "irlba", "widyr", "markdown", "gt", "maps", "mapproj"))


pak::pak(c("showtext", "glue",  "plotly", "fs", "countrycode", "here", "quarto"))
